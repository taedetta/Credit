module.exports = {
  name: 'create_disputes_tables',
  up: async (client) => {
    // Disputes: one per user session of disputing items
    await client.query(`
      CREATE TABLE IF NOT EXISTS disputes (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        session_id VARCHAR(64) NOT NULL,
        bureau VARCHAR(20) NOT NULL CHECK (bureau IN ('equifax', 'experian', 'transunion')),
        status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'generated', 'mailed', 'resolved')),
        personal_info JSONB DEFAULT '{}',
        created_at TIMESTAMPTZ DEFAULT NOW(),
        updated_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Negative items the user wants to dispute
    await client.query(`
      CREATE TABLE IF NOT EXISTS dispute_items (
        id SERIAL PRIMARY KEY,
        dispute_id INTEGER REFERENCES disputes(id) ON DELETE CASCADE,
        item_type VARCHAR(30) NOT NULL CHECK (item_type IN (
          'collection', 'late_payment', 'charge_off', 'repossession',
          'foreclosure', 'bankruptcy', 'judgment', 'tax_lien',
          'unknown_account', 'medical_debt', 'student_loan', 'other'
        )),
        creditor_name VARCHAR(255),
        account_number VARCHAR(100),
        reported_balance NUMERIC(12,2),
        date_opened DATE,
        dispute_reason VARCHAR(50) NOT NULL CHECK (dispute_reason IN (
          'identity_theft', 'inaccurate_balance', 'inaccurate_dates',
          'not_my_account', 'expired_debt', 'paid_debt', 'duplicate_account',
          'mixed_file', 'debt_validation', 'goodwill', 'medical_debt_hipaa',
          'incorrect_status', 'wrong_creditor', 'other'
        )),
        custom_explanation TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Generated letters
    await client.query(`
      CREATE TABLE IF NOT EXISTS dispute_letters (
        id SERIAL PRIMARY KEY,
        dispute_id INTEGER REFERENCES disputes(id) ON DELETE CASCADE,
        template_type VARCHAR(30) NOT NULL,
        letter_content TEXT NOT NULL,
        bureau_address TEXT,
        delivery_method VARCHAR(20) DEFAULT 'pdf' CHECK (delivery_method IN ('pdf', 'mail')),
        mailed_at TIMESTAMPTZ,
        tracking_number VARCHAR(100),
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Indexes
    await client.query(`CREATE INDEX IF NOT EXISTS idx_disputes_session ON disputes(session_id)`);
    await client.query(`CREATE INDEX IF NOT EXISTS idx_disputes_user ON disputes(user_id)`);
    await client.query(`CREATE INDEX IF NOT EXISTS idx_dispute_items_dispute ON dispute_items(dispute_id)`);
    await client.query(`CREATE INDEX IF NOT EXISTS idx_dispute_letters_dispute ON dispute_letters(dispute_id)`);
  }
};

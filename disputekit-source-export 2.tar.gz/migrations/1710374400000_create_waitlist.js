module.exports = {
  name: 'create_waitlist',
  up: async (client) => {
    await client.query(`
      CREATE TABLE IF NOT EXISTS waitlist (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) NOT NULL,
        source VARCHAR(100) DEFAULT 'landing',
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Unique index on email — no duplicates
    await client.query(`
      CREATE UNIQUE INDEX IF NOT EXISTS waitlist_email_unique_idx ON waitlist (LOWER(email))
    `);
  }
};

const express = require('express');
const { Pool } = require('pg');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { BUREAU_ADDRESSES, DISPUTE_REASONS, ITEM_TYPES, generateLetter, determineBestTemplate } = require('./lib/letter-templates');
const { generateLetterHTML } = require('./lib/pdf-generator');
const { parseCreditReport } = require('./lib/credit-report-parser');

const JWT_SECRET = process.env.JWT_SECRET || 'disputekit-dev-secret-change-in-prod';

const app = express();
const port = process.env.PORT || 3000;

// Fail fast if DATABASE_URL is missing
if (!process.env.DATABASE_URL) {
  console.error('ERROR: DATABASE_URL environment variable is required');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false }
});

// File upload config — memory storage, 20MB limit, PDF + TXT
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['application/pdf', 'text/plain'];
    const allowedExts = ['.pdf', '.txt'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(file.mimetype) || allowedExts.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Only PDF or text files are accepted'), false);
    }
  }
});

app.use(express.json());

// Health check endpoint (required for Render)
app.get('/health', (req, res) => {
  res.json({ status: 'healthy' });
});

// Serve static files from public folder
app.use(express.static(path.join(__dirname, 'public')));

// ============================================================
// Auth middleware — attaches req.user if valid JWT is present
// ============================================================
function authenticateToken(req, res, next) {
  const auth = req.headers['authorization'];
  const token = auth && auth.startsWith('Bearer ') ? auth.slice(7) : null;
  if (!token) return res.status(401).json({ success: false, error: 'Authentication required' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ success: false, error: 'Invalid or expired token' });
  }
}

// Optional auth — attaches req.user if valid JWT present, but doesn't block
function optionalAuth(req, res, next) {
  const auth = req.headers['authorization'];
  const token = auth && auth.startsWith('Bearer ') ? auth.slice(7) : null;
  if (token) {
    try { req.user = jwt.verify(token, JWT_SECRET); } catch {}
  }
  next();
}

// ============================================================
// API: Auth — signup, login, me
// ============================================================
app.post('/api/auth/signup', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email and password are required' });
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      return res.status(400).json({ success: false, error: 'Invalid email address' });
    }
    if (password.length < 8) {
      return res.status(400).json({ success: false, error: 'Password must be at least 8 characters' });
    }

    const trimmed = email.trim().toLowerCase();

    // Check for existing user
    const existing = await pool.query('SELECT id FROM users WHERE LOWER(email) = $1', [trimmed]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ success: false, error: 'An account with this email already exists' });
    }

    const password_hash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      'INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING id, email, created_at',
      [trimmed, password_hash]
    );
    const user = result.rows[0];
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '30d' });
    res.json({ success: true, token, user: { id: user.id, email: user.email } });
  } catch (err) {
    console.error('Signup error:', err);
    res.status(500).json({ success: false, error: 'Signup failed. Please try again.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email and password are required' });
    }
    const trimmed = email.trim().toLowerCase();
    const result = await pool.query('SELECT id, email, password_hash FROM users WHERE LOWER(email) = $1', [trimmed]);
    if (result.rows.length === 0) {
      return res.status(401).json({ success: false, error: 'Invalid email or password' });
    }
    const user = result.rows[0];
    if (!user.password_hash) {
      return res.status(401).json({ success: false, error: 'Invalid email or password' });
    }
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ success: false, error: 'Invalid email or password' });
    }
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '30d' });
    res.json({ success: true, token, user: { id: user.id, email: user.email } });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, error: 'Login failed. Please try again.' });
  }
});

app.get('/api/auth/me', authenticateToken, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, email, name, created_at, subscription_status, subscription_plan, subscription_expires_at FROM users WHERE id = $1',
      [req.user.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }
    res.json({ success: true, user: result.rows[0] });
  } catch (err) {
    console.error('Auth me error:', err);
    res.status(500).json({ success: false, error: 'Failed to fetch user' });
  }
});

// ============================================================
// API: Reference data
// ============================================================
app.get('/api/reference', (req, res) => {
  res.json({
    bureaus: Object.entries(BUREAU_ADDRESSES).map(([key, val]) => ({ id: key, ...val })),
    dispute_reasons: Object.entries(DISPUTE_REASONS).map(([key, val]) => ({ id: key, ...val })),
    item_types: Object.entries(ITEM_TYPES).map(([key, val]) => ({ id: key, label: val }))
  });
});

// ============================================================
// API: Create or update dispute
// ============================================================
app.post('/api/disputes', async (req, res) => {
  try {
    const { session_id, bureau, personal_info } = req.body;
    if (!bureau || !BUREAU_ADDRESSES[bureau]) {
      return res.status(400).json({ error: 'Invalid bureau. Must be equifax, experian, or transunion.' });
    }

    const sid = session_id || crypto.randomUUID();

    // Check if dispute exists for this session
    const existing = await pool.query(
      'SELECT id FROM disputes WHERE session_id = $1',
      [sid]
    );

    let disputeId;
    if (existing.rows.length > 0) {
      disputeId = existing.rows[0].id;
      await pool.query(
        'UPDATE disputes SET bureau = $1, personal_info = $2, updated_at = NOW() WHERE id = $3',
        [bureau, JSON.stringify(personal_info || {}), disputeId]
      );
    } else {
      const result = await pool.query(
        'INSERT INTO disputes (session_id, bureau, personal_info) VALUES ($1, $2, $3) RETURNING id',
        [sid, bureau, JSON.stringify(personal_info || {})]
      );
      disputeId = result.rows[0].id;
    }

    res.json({ success: true, dispute_id: disputeId, session_id: sid });
  } catch (err) {
    console.error('Error creating dispute:', err);
    res.status(500).json({ error: 'Failed to create dispute' });
  }
});

// ============================================================
// API: Get dispute by session
// ============================================================
app.get('/api/disputes/:session_id', async (req, res) => {
  try {
    const { session_id } = req.params;
    const dispute = await pool.query(
      'SELECT * FROM disputes WHERE session_id = $1',
      [session_id]
    );
    if (dispute.rows.length === 0) {
      return res.status(404).json({ error: 'Dispute not found' });
    }

    const items = await pool.query(
      'SELECT * FROM dispute_items WHERE dispute_id = $1 ORDER BY id',
      [dispute.rows[0].id]
    );

    const letters = await pool.query(
      'SELECT * FROM dispute_letters WHERE dispute_id = $1 ORDER BY created_at DESC',
      [dispute.rows[0].id]
    );

    res.json({
      dispute: dispute.rows[0],
      items: items.rows,
      letters: letters.rows
    });
  } catch (err) {
    console.error('Error fetching dispute:', err);
    res.status(500).json({ error: 'Failed to fetch dispute' });
  }
});

// ============================================================
// API: Add items to dispute
// ============================================================
app.post('/api/disputes/:dispute_id/items', async (req, res) => {
  try {
    const { dispute_id } = req.params;
    const { items } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Items array is required' });
    }

    // Validate dispute exists
    const dispute = await pool.query('SELECT id FROM disputes WHERE id = $1', [dispute_id]);
    if (dispute.rows.length === 0) {
      return res.status(404).json({ error: 'Dispute not found' });
    }

    // Clear existing items and add new ones
    await pool.query('DELETE FROM dispute_items WHERE dispute_id = $1', [dispute_id]);

    const insertedItems = [];
    for (const item of items) {
      if (!item.item_type || !item.dispute_reason) {
        continue;
      }
      const result = await pool.query(
        `INSERT INTO dispute_items (dispute_id, item_type, creditor_name, account_number, reported_balance, date_opened, dispute_reason, custom_explanation)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
        [dispute_id, item.item_type, item.creditor_name || null, item.account_number || null,
         item.reported_balance || null, item.date_opened || null, item.dispute_reason, item.custom_explanation || null]
      );
      insertedItems.push(result.rows[0]);
    }

    res.json({ success: true, items: insertedItems });
  } catch (err) {
    console.error('Error adding items:', err);
    res.status(500).json({ error: 'Failed to add items' });
  }
});

// ============================================================
// API: Generate letter
// ============================================================
app.post('/api/disputes/:dispute_id/generate', async (req, res) => {
  try {
    const { dispute_id } = req.params;

    // Get dispute with items
    const dispute = await pool.query('SELECT * FROM disputes WHERE id = $1', [dispute_id]);
    if (dispute.rows.length === 0) {
      return res.status(404).json({ error: 'Dispute not found' });
    }

    const items = await pool.query(
      'SELECT * FROM dispute_items WHERE dispute_id = $1 ORDER BY id',
      [dispute_id]
    );
    if (items.rows.length === 0) {
      return res.status(400).json({ error: 'No items to dispute. Add items first.' });
    }

    const d = dispute.rows[0];
    const personalInfo = d.personal_info || {};
    const templateType = determineBestTemplate(items.rows);

    // Generate the letter
    const letterContent = generateLetter(templateType, personalInfo, d.bureau, items.rows);
    const bureauAddr = BUREAU_ADDRESSES[d.bureau];
    const bureauAddress = `${bureauAddr.name}\n${bureauAddr.address}\n${bureauAddr.city}, ${bureauAddr.state} ${bureauAddr.zip}`;

    // Save letter
    const result = await pool.query(
      `INSERT INTO dispute_letters (dispute_id, template_type, letter_content, bureau_address)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [dispute_id, templateType, letterContent, bureauAddress]
    );

    // Update dispute status
    await pool.query('UPDATE disputes SET status = $1, updated_at = NOW() WHERE id = $2', ['generated', dispute_id]);

    res.json({
      success: true,
      letter: result.rows[0],
      template_type: templateType
    });
  } catch (err) {
    console.error('Error generating letter:', err);
    res.status(500).json({ error: 'Failed to generate letter' });
  }
});

// ============================================================
// API: Get letter as printable HTML (for PDF)
// ============================================================
app.get('/api/letters/:letter_id/print', async (req, res) => {
  try {
    const { letter_id } = req.params;
    const letter = await pool.query('SELECT * FROM dispute_letters WHERE id = $1', [letter_id]);
    if (letter.rows.length === 0) {
      return res.status(404).json({ error: 'Letter not found' });
    }

    const l = letter.rows[0];
    const dispute = await pool.query('SELECT * FROM disputes WHERE id = $1', [l.dispute_id]);
    const personalInfo = dispute.rows[0]?.personal_info || {};

    const html = generateLetterHTML(l.letter_content, personalInfo, dispute.rows[0]?.bureau);
    res.type('html').send(html);
  } catch (err) {
    console.error('Error generating printable letter:', err);
    res.status(500).json({ error: 'Failed to generate printable letter' });
  }
});

// ============================================================
// Shared: Extract text from an uploaded file (PDF or TXT)
// ============================================================
async function extractTextFromFile(file) {
  const ext = path.extname(file.originalname).toLowerCase();
  const isTxt = ext === '.txt' || file.mimetype === 'text/plain';

  if (isTxt) {
    // Text files: just decode the buffer
    const text = file.buffer.toString('utf8');
    return { text, pages: 1 };
  }

  // PDF files: use pdf-parse v2 (PDFParse class API)
  // v2.4.5 exports { PDFParse } - NOT a function, NOT .default, NOT .parse
  // Usage: new PDFParse({ data: buffer }) -> await parser.getText() -> { text, total }
  const { PDFParse } = require('pdf-parse');
  const parser = new PDFParse({ data: file.buffer });
  let pdfResult;
  try {
    pdfResult = await parser.getText();
  } finally {
    parser.destroy().catch(() => {});
  }
  return { text: pdfResult.text, pages: pdfResult.total };
}

// ============================================================
// API: Upload and parse credit report PDF or TXT (single file)
// ============================================================
app.post('/api/upload-credit-report', upload.single('pdf'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, error: 'No file uploaded' });
    }

    let extracted;
    try {
      extracted = await extractTextFromFile(req.file);
    } catch (parseErr) {
      console.error('File parse error:', parseErr.message);
      return res.status(422).json({
        success: false,
        error: 'Could not read this file. PDFs must be digitally generated (not scanned). Try a different file or use manual entry.',
        details: parseErr.message
      });
    }

    if (!extracted.text || extracted.text.trim().length < 50) {
      return res.status(422).json({
        success: false,
        error: 'No text content found. PDFs must be digitally generated (not scanned images). Please use manual entry instead.'
      });
    }

    // Parse the credit report text
    const bureauHint = req.body.bureau || null;
    const result = parseCreditReport(extracted.text, bureauHint);

    res.json({
      success: true,
      items: result.items,
      bureau: result.bureau,
      total_accounts: result.total_accounts,
      negative_count: result.negative_count,
      pages: extracted.pages,
      warning: result.error || null
    });
  } catch (err) {
    console.error('Upload error:', err);
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(413).json({ success: false, error: 'File too large. Maximum size is 20MB.' });
    }
    if (err.message && err.message.includes('Only PDF or text files')) {
      return res.status(400).json({ success: false, error: err.message });
    }
    res.status(500).json({ success: false, error: 'Failed to process credit report. Please try again.' });
  }
});

// ============================================================
// API: Upload multiple credit reports (up to 3 files, one per bureau)
// ============================================================
app.post('/api/upload-credit-reports', upload.array('files', 3), async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ success: false, error: 'No files uploaded' });
    }

    const allItems = [];
    const bureauResults = {};
    const seen = new Set();
    let totalPages = 0;

    for (const file of req.files) {
      let extracted;
      try {
        extracted = await extractTextFromFile(file);
      } catch (parseErr) {
        console.error(`File parse error for ${file.originalname}:`, parseErr.message);
        continue; // skip unreadable files, process the rest
      }

      if (!extracted.text || extracted.text.trim().length < 50) continue;

      // Check for bureau hint in field name (e.g. files[experian])
      const bureauHint = req.body[`bureau_${req.files.indexOf(file)}`] || null;
      const result = parseCreditReport(extracted.text, bureauHint);

      totalPages += extracted.pages;

      const bureauKey = result.bureau || 'unknown';

      if (!bureauResults[bureauKey]) {
        bureauResults[bureauKey] = { bureau: bureauKey, items: [], total: 0, negative: 0 };
      }

      // Deduplicate across files
      for (const item of result.items) {
        const key = `${(item.creditor_name || '').toLowerCase().substring(0, 20)}|${(item.account_number || '').slice(-4)}|${bureauKey}`;
        if (!seen.has(key) && item.creditor_name) {
          seen.add(key);
          item.bureau_source = item.bureau_source || bureauKey;
          bureauResults[bureauKey].items.push(item);
          allItems.push(item);
        }
      }
    }

    // Update totals per bureau
    for (const bKey of Object.keys(bureauResults)) {
      const br = bureauResults[bKey];
      br.total = br.items.length;
      br.negative = br.items.filter(i => i.is_negative).length;
    }

    res.json({
      success: true,
      items: allItems,
      bureaus: Object.values(bureauResults),
      total_accounts: allItems.length,
      negative_count: allItems.filter(i => i.is_negative).length,
      files_processed: req.files.length,
      warning: allItems.length === 0 ? 'Could not extract account information from the uploaded files.' : null
    });
  } catch (err) {
    console.error('Multi-upload error:', err);
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(413).json({ success: false, error: 'File too large. Maximum size is 20MB per file.' });
    }
    res.status(500).json({ success: false, error: 'Failed to process credit reports. Please try again.' });
  }
});

// ============================================================
// API: Waitlist signup
// ============================================================
app.post('/api/waitlist', async (req, res) => {
  try {
    const { email, source, _hp } = req.body;

    // Honeypot — bots fill this, humans don't
    if (_hp && _hp.trim().length > 0) {
      // Silently accept so bots don't know they were caught
      return res.json({ success: true });
    }

    // Validate email
    if (!email || typeof email !== 'string') {
      return res.status(400).json({ success: false, error: 'Email is required.' });
    }

    const trimmed = email.trim().toLowerCase();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmed)) {
      return res.status(400).json({ success: false, error: 'Please enter a valid email address.' });
    }

    const src = (source && typeof source === 'string') ? source.slice(0, 100) : 'landing';

    // Upsert — ignore duplicate emails
    await pool.query(
      `INSERT INTO waitlist (email, source) VALUES ($1, $2)
       ON CONFLICT DO NOTHING`,
      [trimmed, src]
    );

    res.json({ success: true });
  } catch (err) {
    console.error('Waitlist signup error:', err);
    res.status(500).json({ success: false, error: 'Something went wrong. Please try again.' });
  }
});

// Multer error handler
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(413).json({ success: false, error: 'File too large. Maximum size is 20MB.' });
    }
    return res.status(400).json({ success: false, error: err.message });
  }
  if (err.message === 'Only PDF files are accepted') {
    return res.status(400).json({ success: false, error: err.message });
  }
  next(err);
});

// ============================================================
// Landing page with analytics beacon
// ============================================================
app.get('/', (req, res) => {
  const slug = process.env.POLSIA_ANALYTICS_SLUG || '';
  const htmlPath = path.join(__dirname, 'public', 'index.html');

  if (fs.existsSync(htmlPath)) {
    let html = fs.readFileSync(htmlPath, 'utf8');
    html = html.replace('__POLSIA_SLUG__', slug);
    res.type('html').send(html);
  } else {
    res.json({ message: 'DisputeKit API' });
  }
});

// Auth pages
app.get('/signup', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'signup.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Manual entry wizard — serve manual-entry.html for /app/manual routes
app.get('/app/manual*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'manual-entry.html'));
});

// SPA fallback — serve app.html for /app routes
app.get('/app*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'app.html'));
});

app.listen(port, () => {
  console.log(`DisputeKit running on port ${port}`);
});
